Trabalho 2

Descrever um Hardware em VHDL para ser embarcado em FPGA, que realize as
seguintes operações de um relógio digital, este deve conter data no formato (DD/MM/
AAAA) e Horas, Minutos e Segundos.
O Kit possui 8 displays de sete segmentos, portanto, o hardware deve possuir uma
entrada para selecionar entre mostrar data ou tempo, outras três entradas devem fazer os
ajustes dos parâmetros que estarão sendo visualizados no momento.
